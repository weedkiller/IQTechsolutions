﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace NBitcoin.Tests
//{
//	public class Program
//	{
//		public static void Main()
//		{
//			//new Secp256k1Tests(null).can_sign_deterministically();
//			//new key_tests().key_test1();
//			//new Secp256k1Tests(null).run_ge();
//		}
//	}
//}
