﻿namespace NBitcoin
{
	public interface ISecret
	{
		Key PrivateKey
		{
			get;
		}
	}
}
