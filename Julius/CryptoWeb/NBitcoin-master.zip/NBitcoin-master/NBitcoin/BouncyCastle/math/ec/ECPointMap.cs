﻿namespace NBitcoin.BouncyCastle.Math.EC
{
	internal interface ECPointMap
	{
		ECPoint Map(ECPoint p);
	}
}
