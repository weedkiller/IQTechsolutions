namespace NBitcoin.BouncyCastle.Crypto
{
	/**
     * all parameter classes implement this.
     */
	internal interface ICipherParameters
	{
	}
}
