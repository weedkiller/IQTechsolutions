﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NBitcoin
{
	public enum Language
	{
		English,
		Japanese,
		Spanish,
		ChineseSimplified,
		ChineseTraditional,
		French,
		PortugueseBrazil,
		Czech,
		Unknown
	};
}
